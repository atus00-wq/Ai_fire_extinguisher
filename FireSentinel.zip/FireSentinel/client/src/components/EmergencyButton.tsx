import React from 'react';
import { Button } from '@/components/ui/button';

interface EmergencyButtonProps {
  onEmergencyClick: () => void;
}

const EmergencyButton: React.FC<EmergencyButtonProps> = ({ onEmergencyClick }) => {
  return (
    <Button 
      className="absolute right-4 top-20 z-30 bg-[hsl(var(--fire-red))] text-white rounded-full p-3 shadow-lg h-12 w-12 flex items-center justify-center"
      onClick={onEmergencyClick}
    >
      <i className="material-icons">sos</i>
    </Button>
  );
};

export default EmergencyButton;
